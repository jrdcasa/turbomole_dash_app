"""
Dash layout. Three tabs:
  1. New job      — structure upload, method/basis, task, submission
  2. Job manager  — table of jobs with actions (download, clean, cancel)
  3. Clusters     — read-only view of configured clusters
"""

from __future__ import annotations

from dash import dcc, html
import dash_bootstrap_components as dbc

from backend.config import AppConfig
from backend.turbomole_io import (
    available_functionals, available_basis_sets, TASK_TYPES, SUPPORTED_INPUT_FORMATS,
)


def build_layout(cfg: AppConfig) -> html.Div:
    return html.Div(
        [
            _navbar(),
            dbc.Container(
                [
                    dcc.Store(id="job-staging-store"),
                    dcc.Store(id="last-action"),
                    dbc.Tabs(
                        [
                            dbc.Tab(_tab_new_job(cfg), label="New job", tab_id="tab-new"),
                            dbc.Tab(_tab_jobs(),       label="Job manager", tab_id="tab-jobs"),
                            dbc.Tab(_tab_clusters(cfg),label="Clusters", tab_id="tab-clusters"),
                        ],
                        id="main-tabs",
                        active_tab="tab-new",
                        className="mt-3",
                    ),
                ],
                fluid=True,
                className="pb-5",
            ),
            html.Div(id="toast-container",
                     style={"position": "fixed", "top": 70, "right": 20, "zIndex": 1080}),
        ]
    )


def _navbar() -> dbc.Navbar:
    return dbc.Navbar(
        dbc.Container(
            [
                dbc.NavbarBrand(
                    [html.I(className="bi bi-cpu me-2"),
                     "Turbomole Orchestrator"],
                    className="fw-bold"
                ),
                html.Span("local ↔ HPC bridge", className="text-muted small"),
            ],
            fluid=True,
        ),
        color="dark", dark=True, sticky="top",
    )


# ---------------------------------------------------------------------------
# Tab 1 — New job
# ---------------------------------------------------------------------------

def _tab_new_job(cfg: AppConfig) -> html.Div:
    cluster_options = [{"label": c, "value": c} for c in cfg.clusters.keys()]

    return html.Div(
        [
            dbc.Row(
                [
                    dbc.Col(_card_structure(), md=6),
                    dbc.Col(_card_method(), md=6),
                ],
                className="g-3 mt-1",
            ),
            dbc.Row(
                [
                    dbc.Col(_card_task(), md=6),
                    dbc.Col(_card_submission(cluster_options), md=6),
                ],
                className="g-3",
            ),
            dbc.Row(
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.H5("Preview (define.inp)", className="card-title"),
                                html.Pre(id="preview-control",
                                         style={"maxHeight": "300px", "overflow": "auto",
                                                "fontSize": "0.78rem"}),
                            ]
                        ),
                        className="shadow-sm",
                    ),
                ),
                className="g-3",
            ),
            dbc.Row(
                dbc.Col(
                    html.Div(
                        [
                            dbc.Button("Preview define.inp", id="btn-preview",
                                       color="secondary", outline=True, className="me-2"),
                            dbc.Button([html.I(className="bi bi-rocket-takeoff me-1"),
                                        "Build & submit"],
                                       id="btn-submit", color="success"),
                        ],
                        className="text-end",
                    )
                ),
                className="g-3 mt-2",
            ),
        ]
    )


def _card_structure() -> dbc.Card:
    return dbc.Card(
        dbc.CardBody(
            [
                html.H5([html.I(className="bi bi-diagram-3 me-2"), "Structure"],
                        className="card-title"),
                dcc.Upload(
                    id="upload-structure",
                    children=html.Div(
                        ["Drop structure file or ", html.A("browse")],
                        className="text-center text-muted",
                    ),
                    style={
                        "borderWidth": "1px", "borderStyle": "dashed",
                        "borderRadius": "8px", "padding": "1.5rem",
                        "cursor": "pointer",
                    },
                    multiple=False,
                ),
                html.Small(
                    f"Accepted: {', '.join(SUPPORTED_INPUT_FORMATS)}",
                    className="text-muted",
                ),
                html.Div(id="structure-summary", className="mt-2"),
                dbc.Row(
                    [
                        dbc.Col(dbc.Label("Charge"), width=4),
                        dbc.Col(dbc.Input(id="inp-charge", type="number", value=0, step=1), width=2),
                        dbc.Col(dbc.Label("Multiplicity"), width=4),
                        dbc.Col(dbc.Input(id="inp-mult", type="number", value=1, min=1, step=1), width=2),
                    ],
                    className="mt-3 g-2 align-items-center",
                ),
            ]
        ),
        className="shadow-sm h-100",
    )


def _card_method() -> dbc.Card:
    return dbc.Card(
        dbc.CardBody(
            [
                html.H5([html.I(className="bi bi-sliders me-2"), "Method"],
                        className="card-title"),
                dbc.Label("Functional"),
                dcc.Dropdown(
                    id="dd-functional",
                    options=[{"label": f, "value": f} for f in available_functionals()],
                    value="BP86", clearable=False,
                ),
                dbc.Label("Basis set", className="mt-3"),
                dcc.Dropdown(
                    id="dd-basis",
                    options=[{"label": b, "value": b} for b in available_basis_sets()],
                    value="def2-SVP", clearable=False,
                ),
                dbc.Checklist(
                    options=[{"label": " Use RI (recommended for DFT)", "value": "ri"}],
                    value=["ri"], id="chk-ri", switch=True, className="mt-3",
                ),
                dbc.Label("SCF grid", className="mt-2"),
                dcc.Dropdown(
                    id="dd-grid",
                    options=[{"label": g, "value": g} for g in ("m3", "m4", "m5")],
                    value="m4", clearable=False,
                ),
            ]
        ),
        className="shadow-sm h-100",
    )


def _card_task() -> dbc.Card:
    return dbc.Card(
        dbc.CardBody(
            [
                html.H5([html.I(className="bi bi-list-task me-2"), "Task"],
                        className="card-title"),
                dbc.RadioItems(
                    id="rad-task",
                    options=[
                        {"label": " Single point",       "value": "single_point"},
                        {"label": " Geometry optimization", "value": "optimization"},
                        {"label": " Ab initio MD (frog)", "value": "aimd"},
                    ],
                    value="single_point",
                    inline=False,
                ),
                html.Div(
                    [
                        dbc.Row(
                            [
                                dbc.Col(dbc.Label("MD steps"), width=4),
                                dbc.Col(dbc.Input(id="inp-aimd-steps", type="number",
                                                  value=500, min=1), width=8),
                            ],
                            className="g-2 mt-2 align-items-center",
                        ),
                        dbc.Row(
                            [
                                dbc.Col(dbc.Label("Δt (fs)"), width=4),
                                dbc.Col(dbc.Input(id="inp-aimd-dt", type="number",
                                                  value=0.5, min=0.01, step=0.01), width=8),
                            ],
                            className="g-2 align-items-center",
                        ),
                        dbc.Row(
                            [
                                dbc.Col(dbc.Label("T (K)"), width=4),
                                dbc.Col(dbc.Input(id="inp-aimd-T", type="number",
                                                  value=300, min=1), width=8),
                            ],
                            className="g-2 align-items-center",
                        ),
                    ],
                    id="aimd-params", style={"display": "none"},
                ),
            ]
        ),
        className="shadow-sm h-100",
    )


def _card_submission(cluster_options: list) -> dbc.Card:
    return dbc.Card(
        dbc.CardBody(
            [
                html.H5([html.I(className="bi bi-hdd-network me-2"), "Submission"],
                        className="card-title"),
                dbc.Label("Job name"),
                dbc.Input(id="inp-job-name", placeholder="e.g. ferrocene_opt"),
                dbc.Label("Cluster", className="mt-2"),
                dcc.Dropdown(
                    id="dd-cluster", options=cluster_options,
                    value=cluster_options[0]["value"] if cluster_options else None,
                    clearable=False,
                ),
                dbc.Row(
                    [
                        dbc.Col([dbc.Label("Partition"),
                                 dbc.Input(id="inp-partition")], md=6),
                        dbc.Col([dbc.Label("Walltime"),
                                 dbc.Input(id="inp-walltime")], md=6),
                    ],
                    className="g-2 mt-2",
                ),
                dbc.Row(
                    [
                        dbc.Col([dbc.Label("Nodes"),
                                 dbc.Input(id="inp-nodes", type="number", min=1)], md=4),
                        dbc.Col([dbc.Label("ntasks"),
                                 dbc.Input(id="inp-ntasks", type="number", min=1)], md=4),
                        dbc.Col([dbc.Label("Memory"),
                                 dbc.Input(id="inp-mem")], md=4),
                    ],
                    className="g-2 mt-2",
                ),
            ]
        ),
        className="shadow-sm h-100",
    )


# ---------------------------------------------------------------------------
# Tab 2 — Job manager
# ---------------------------------------------------------------------------

def _tab_jobs() -> html.Div:
    return html.Div(
        [
            dbc.Alert(
                [
                    html.I(className="bi bi-info-circle me-2"),
                    "Job states are not auto-refreshed. Click ",
                    html.B("Refresh status"),
                    " to query SLURM on the cluster(s).",
                ],
                color="info",
                className="mt-3 py-2 small",
            ),
            html.Div(
                [
                    dbc.Button(
                        [html.I(className="bi bi-arrow-clockwise me-1"),
                         "Refresh status"],
                        id="btn-refresh-jobs",
                        color="primary",
                    ),
                    html.Span(
                        id="jobs-last-updated",
                        className="ms-3 text-muted small",
                    ),
                ],
                className="mb-3 d-flex align-items-center",
            ),
            html.Div(id="jobs-table-container"),
        ]
    )


# ---------------------------------------------------------------------------
# Tab 3 — Clusters
# ---------------------------------------------------------------------------

def _tab_clusters(cfg: AppConfig) -> html.Div:
    cards = []
    for name, c in cfg.clusters.items():
        cards.append(
            dbc.Col(
                dbc.Card(
                    dbc.CardBody(
                        [
                            html.H5(name, className="card-title"),
                            html.Div([html.Strong("Host: "), f"{c.user}@{c.host}:{c.port}"]),
                            html.Div([html.Strong("Workdir: "), html.Code(c.remote_workdir)]),
                            html.Div([html.Strong("Turbomole version: "),
                                      dbc.Badge(c.turbomole_version, color="primary",
                                                className="ms-1")]),
                            html.Div([html.Strong("Default partition: "), c.default_partition]),
                            html.Div([html.Strong("Modules: "),
                                      ", ".join(c.module_load) or html.Em("(none)")]),
                            html.Div([html.Strong("env_setup: "),
                                      html.Em("(none)") if not c.env_setup
                                      else html.Code(f"{len(c.env_setup)} line(s)")]),
                            dbc.Button([html.I(className="bi bi-plug me-1"), "Test connection"],
                                       id={"type": "btn-test-cluster", "name": name},
                                       color="primary", outline=True, size="sm",
                                       className="mt-2"),
                            html.Span(id={"type": "test-cluster-out", "name": name},
                                      className="ms-2 small"),
                        ]
                    ),
                    className="shadow-sm h-100",
                ),
                md=6, className="mt-3",
            )
        )
    return html.Div(dbc.Row(cards, className="g-3"))
