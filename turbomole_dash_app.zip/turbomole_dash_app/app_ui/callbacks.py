"""
Dash callbacks.

Heavy I/O (SSH, large uploads/downloads) is delegated to a thread pool so
the UI never blocks. SLURM status polling is *on demand* (triggered by
the Refresh button), not via a background daemon.
"""

from __future__ import annotations

import base64
import logging
import pickle
import shutil
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import dash
from dash import Input, Output, State, ALL, ctx, html, no_update
import dash_bootstrap_components as dbc

from backend.config import AppConfig
from backend.db import (
    JobRecord, insert_job, list_jobs, get_job, update_job,
)
from backend.slurm import SlurmParams, build_slurm_script
from backend.turbomole_io import (
    SUPPORTED_INPUT_FORMATS, build_control_file, load_structure_from_bytes,
    turbomole_driver_commands,
)
from remote import slurm_remote, ssh_client
from workers.poller import refresh_active_jobs, refresh_single_job


log = logging.getLogger("callbacks")
_EXECUTOR = ThreadPoolExecutor(max_workers=4, thread_name_prefix="tm-io")


def register_callbacks(app: dash.Dash, cfg: AppConfig) -> None:
    # No background thread — status is refreshed on demand from the UI.
    _register_new_job_callbacks(app, cfg)
    _register_jobs_table_callbacks(app, cfg)
    _register_cluster_test_callback(app, cfg)


# ===========================================================================
# Tab 1 — New job
# ===========================================================================

def _register_new_job_callbacks(app: dash.Dash, cfg: AppConfig) -> None:

    # Fill defaults when the user picks a cluster
    @app.callback(
        Output("inp-partition", "value"),
        Output("inp-walltime",  "value"),
        Output("inp-nodes",     "value"),
        Output("inp-ntasks",    "value"),
        Output("inp-mem",       "value"),
        Input("dd-cluster", "value"),
    )
    def _fill_cluster_defaults(name):
        if not name or name not in cfg.clusters:
            return no_update, no_update, no_update, no_update, no_update
        c = cfg.clusters[name]
        return c.default_partition, c.default_time, c.default_nodes, c.default_ntasks, c.default_mem

    # Toggle AIMD-specific block
    @app.callback(
        Output("aimd-params", "style"),
        Input("rad-task", "value"),
    )
    def _toggle_aimd(task):
        return {"display": "block"} if task == "aimd" else {"display": "none"}

    # Parse uploaded structure → store atoms
    @app.callback(
        Output("job-staging-store", "data"),
        Output("structure-summary", "children"),
        Input("upload-structure", "contents"),
        State("upload-structure", "filename"),
        prevent_initial_call=True,
    )
    def _parse_structure(contents, filename):
        if contents is None:
            return no_update, no_update
        try:
            _, b64 = contents.split(",", 1)
            data = base64.b64decode(b64)
            fmt = (Path(filename).suffix.lstrip(".") or "xyz").lower()
            if fmt not in SUPPORTED_INPUT_FORMATS:
                # heuristic: try xyz for unknown extensions
                fmt = "xyz"
            atoms = load_structure_from_bytes(data, fmt)
            payload = base64.b64encode(pickle.dumps(atoms)).decode()
            summary = dbc.Alert(
                [
                    html.I(className="bi bi-check-circle me-2"),
                    f"{filename} — {len(atoms)} atoms, formula ",
                    html.Code(atoms.get_chemical_formula()),
                ],
                color="success", className="py-2 mb-0",
            )
            return {"atoms_b64": payload, "filename": filename}, summary
        except Exception as exc:  # noqa: BLE001
            return no_update, dbc.Alert(
                f"Could not parse: {exc}", color="danger", className="py-2 mb-0",
            )

    # Preview the generated define.inp
    @app.callback(
        Output("preview-control", "children"),
        Input("btn-preview", "n_clicks"),
        State("job-staging-store", "data"),
        State("dd-cluster", "value"),
        State("dd-functional", "value"),
        State("dd-basis", "value"),
        State("rad-task", "value"),
        State("inp-charge", "value"),
        State("inp-mult", "value"),
        State("chk-ri", "value"),
        State("dd-grid", "value"),
        State("inp-aimd-steps", "value"),
        State("inp-aimd-dt", "value"),
        State("inp-aimd-T", "value"),
        prevent_initial_call=True,
    )
    def _preview(n, staging, cluster_name,
                 functional, basis, task, charge, mult,
                 ri, grid, aimd_steps, aimd_dt, aimd_T):
        if not staging:
            return "Upload a structure first."
        # Resolve Turbomole version from the selected cluster (fallback to 7.8)
        tm_version = "7.8"
        if cluster_name and cluster_name in cfg.clusters:
            tm_version = cfg.clusters[cluster_name].turbomole_version

        atoms = pickle.loads(base64.b64decode(staging["atoms_b64"]))
        tmp = cfg.local_workdir / f".preview_{int(time.time())}"
        try:
            build_control_file(
                atoms, tmp,
                functional=functional, basis_set=basis, task_type=task,
                charge=int(charge or 0), multiplicity=int(mult or 1),
                grid=grid, use_ri="ri" in (ri or []),
                aimd_steps=int(aimd_steps or 500),
                aimd_timestep_fs=float(aimd_dt or 0.5),
                aimd_temperature_K=float(aimd_T or 300),
                turbomole_version=tm_version,
            )
            define_text = (tmp / "define.inp").read_text()
            header = (
                f"# Turbomole {tm_version} — define.inp\n"
                f"# (the control file will be generated on the cluster\n"
                f"#  by running:  define < define.inp)\n"
                f"#\n"
            )
            return header + define_text
        except Exception as exc:  # noqa: BLE001
            return f"# Error: {exc}"
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    # Build & submit
    @app.callback(
        Output("last-action", "data", allow_duplicate=True),
        Output("main-tabs", "active_tab"),
        Input("btn-submit", "n_clicks"),
        State("job-staging-store", "data"),
        State("inp-job-name", "value"),
        State("dd-cluster", "value"),
        State("dd-functional", "value"),
        State("dd-basis", "value"),
        State("rad-task", "value"),
        State("inp-charge", "value"),
        State("inp-mult", "value"),
        State("chk-ri", "value"),
        State("dd-grid", "value"),
        State("inp-aimd-steps", "value"),
        State("inp-aimd-dt", "value"),
        State("inp-aimd-T", "value"),
        State("inp-partition", "value"),
        State("inp-walltime", "value"),
        State("inp-nodes", "value"),
        State("inp-ntasks", "value"),
        State("inp-mem", "value"),
        prevent_initial_call=True,
    )
    def _submit(n, staging, job_name, cluster_name,
                functional, basis, task, charge, mult, ri, grid,
                aimd_steps, aimd_dt, aimd_T,
                partition, walltime, nodes, ntasks, mem):
        if not n:
            return no_update, no_update
        try:
            if not staging:
                raise ValueError("No structure uploaded.")
            if not job_name:
                raise ValueError("Please provide a job name.")
            cluster = cfg.clusters[cluster_name]
            atoms = pickle.loads(base64.b64decode(staging["atoms_b64"]))

            use_ri = "ri" in (ri or [])

            # 1. Build local job directory
            ts = time.strftime("%Y%m%d-%H%M%S")
            safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in job_name)
            local_dir = cfg.local_workdir / f"{safe_name}_{ts}"
            local_dir.mkdir(parents=True, exist_ok=False)

            build_control_file(
                atoms, local_dir,
                functional=functional, basis_set=basis, task_type=task,
                charge=int(charge or 0), multiplicity=int(mult or 1),
                grid=grid, use_ri=use_ri,
                aimd_steps=int(aimd_steps or 500),
                aimd_timestep_fs=float(aimd_dt or 0.5),
                aimd_temperature_K=float(aimd_T or 300),
                turbomole_version=cluster.turbomole_version,
            )

            # 2. Build SLURM script
            sl = SlurmParams(
                job_name=safe_name,
                partition=partition or cluster.default_partition,
                time=walltime or cluster.default_time,
                nodes=int(nodes or cluster.default_nodes),
                ntasks=int(ntasks or cluster.default_ntasks),
                mem=mem or cluster.default_mem,
            )
            base_remote = ssh_client.expand_remote(cluster, cluster.remote_workdir)
            remote_dir = f"{base_remote.rstrip('/')}/{safe_name}_{ts}"

            script = build_slurm_script(
                sl, remote_dir, cluster.module_load,
                turbomole_driver_commands(
                    task,
                    turbomole_version=cluster.turbomole_version,
                    functional=functional,
                    basis_set=basis,
                    use_ri=use_ri,
                ),
                env_setup=cluster.env_setup,
            )
            (local_dir / "submit.slurm").write_text(script)

            # 3. Persist as DRAFT before any network work
            rec = JobRecord(
                name=job_name, cluster=cluster_name, state="DRAFT",
                task_type=task, local_dir=str(local_dir), remote_dir=remote_dir,
                functional=functional, basis_set=basis,
                charge=int(charge or 0), multiplicity=int(mult or 1),
                submit_meta={
                    "partition": sl.partition, "time": sl.time,
                    "nodes": sl.nodes, "ntasks": sl.ntasks, "mem": sl.mem,
                    "turbomole_version": cluster.turbomole_version,
                },
            )
            job_id = insert_job(rec)

            # 4. Upload + submit (in worker so UI does not block on slow SSH)
            _EXECUTOR.submit(_upload_and_submit, cfg, job_id)

            return {
                "ok": True,
                "msg": f"Job '{job_name}' queued for upload to {cluster_name}.",
                "ts": time.time(),
            }, "tab-jobs"
        except Exception as exc:  # noqa: BLE001
            log.exception("Submit failed")
            return {"ok": False, "msg": f"Submit failed: {exc}", "ts": time.time()}, no_update


def _upload_and_submit(cfg: AppConfig, job_id: int) -> None:
    """Runs in the executor: SFTP upload + sbatch."""
    job = get_job(job_id)
    if job is None:
        return
    cluster = cfg.clusters[job["cluster"]]
    try:
        ssh_client.upload_dir(cluster, Path(job["local_dir"]), job["remote_dir"])
        update_job(job_id, state="UPLOADED")
        slurm_id = slurm_remote.submit(cluster, job["remote_dir"], "submit.slurm")
        update_job(job_id, state="SUBMITTED", slurm_id=slurm_id)
        log.info("Job %s submitted as SLURM %s", job_id, slurm_id)
    except Exception as exc:  # noqa: BLE001
        log.exception("Upload/submit failed for job %s", job_id)
        update_job(job_id, state="FAILED",
                   extra={"error": str(exc), "trace": traceback.format_exc()})


# ===========================================================================
# Tab 2 — Job manager
# ===========================================================================

_STATE_COLORS = {
    "DRAFT": "secondary", "UPLOADED": "info", "SUBMITTED": "info",
    "PENDING": "warning", "RUNNING": "primary",
    "COMPLETED": "success", "FAILED": "danger",
    "DOWNLOADED": "success", "CLEANED": "dark",
}


def _register_jobs_table_callbacks(app: dash.Dash, cfg: AppConfig) -> None:

    @app.callback(
        Output("jobs-table-container", "children"),
        Output("jobs-last-updated", "children"),
        Output("last-action", "data", allow_duplicate=True),
        Input("btn-refresh-jobs", "n_clicks"),
        Input("last-action", "data"),
        Input("main-tabs", "active_tab"),
        prevent_initial_call="initial_duplicate",
    )
    def _render_jobs_table(_n_click, _action, _tab):
        """Re-render the jobs table.

        The SLURM query only runs when the user explicitly clicks the
        refresh button; other triggers (a fresh action, switching tabs)
        just re-read the DB.
        """
        triggered = ctx.triggered_id
        feedback = no_update

        if triggered == "btn-refresh-jobs":
            report = refresh_active_jobs(cfg)
            feedback = {
                "ok":  report.errors == 0,
                "msg": report.summary(),
                "ts":  time.time(),
            }
            if report.details:
                log.info("Refresh details: %s", report.details)

        jobs = list_jobs()
        if not jobs:
            return (
                dbc.Alert("No jobs yet. Submit one from the 'New job' tab.",
                          color="secondary"),
                "",
                feedback,
            )

        header = html.Thead(html.Tr([
            html.Th("ID"), html.Th("Name"), html.Th("Cluster"),
            html.Th("SLURM"), html.Th("Task"), html.Th("State"),
            html.Th("Created"), html.Th("Actions"),
        ]))
        rows = [_job_row(j) for j in jobs]
        table = dbc.Table(
            [header, html.Tbody(rows)],
            bordered=False, hover=True, responsive=True, striped=True,
            className="align-middle",
        )
        return table, f"Last refreshed at {time.strftime('%H:%M:%S')}", feedback

    # ----- Action buttons (pattern-matching) -----
    @app.callback(
        Output("last-action", "data", allow_duplicate=True),
        Input({"type": "job-action", "action": ALL, "id": ALL}, "n_clicks"),
        prevent_initial_call=True,
    )
    def _handle_action(_clicks):
        trig = ctx.triggered_id
        if not trig or not any(_clicks):
            return no_update
        action = trig["action"]
        job_id = int(trig["id"])
        try:
            # Refresh state for this job before acting, so Download works the
            # instant the job finishes (no need to click Refresh first)
            if action in ("download-final", "download-and-clean"):
                refresh_single_job(cfg, job_id)

            if action == "download-partial":
                _EXECUTOR.submit(_action_download, cfg, job_id, partial=True, clean=False)
                msg = f"Streaming partial outputs for job {job_id}…"
            elif action == "download-final":
                _EXECUTOR.submit(_action_download, cfg, job_id, partial=False, clean=False)
                msg = f"Downloading finished outputs for job {job_id}…"
            elif action == "download-and-clean":
                _EXECUTOR.submit(_action_download, cfg, job_id, partial=False, clean=True)
                msg = f"Downloading + cleaning remote dir for job {job_id}…"
            elif action == "cancel":
                _action_cancel(cfg, job_id)
                msg = f"Cancelled job {job_id}."
            else:
                msg = f"Unknown action: {action}"
            return {"ok": True, "msg": msg, "ts": time.time()}
        except Exception as exc:  # noqa: BLE001
            log.exception("Action %s on job %s failed", action, job_id)
            return {"ok": False, "msg": f"{action} failed: {exc}", "ts": time.time()}

    # ----- Toast feedback -----
    @app.callback(
        Output("toast-container", "children"),
        Input("last-action", "data"),
        prevent_initial_call=True,
    )
    def _show_toast(data):
        if not data:
            return no_update
        return dbc.Toast(
            data.get("msg", ""),
            header="Turbomole Orchestrator",
            icon="success" if data.get("ok") else "danger",
            duration=4500, is_open=True, dismissable=True,
            style={"minWidth": "320px"},
        )


def _job_row(j: dict) -> html.Tr:
    state = j["state"]
    badge = dbc.Badge(state, color=_STATE_COLORS.get(state, "secondary"),
                      className="px-2 py-1")
    actions = []
    job_id = j["id"]

    # Running / pending → partial download + cancel
    if state in ("RUNNING", "PENDING", "SUBMITTED", "UPLOADED"):
        actions.append(_action_btn("download-partial", job_id,
                                   "bi-download", "Partial", "info"))
        actions.append(_action_btn("cancel", job_id, "bi-x-circle",
                                   "Cancel", "danger"))
    # Finished → download / download+clean
    if state in ("COMPLETED", "FAILED"):
        actions.append(_action_btn("download-final", job_id,
                                   "bi-download", "Download", "success"))
        actions.append(_action_btn("download-and-clean", job_id,
                                   "bi-trash", "DL + clean", "warning"))
    # Already downloaded
    if state in ("DOWNLOADED", "CLEANED"):
        actions.append(html.Span(
            html.A("open folder", href=f"file://{j['local_dir']}", target="_blank"),
            className="small text-muted",
        ))

    return html.Tr([
        html.Td(job_id),
        html.Td(j["name"]),
        html.Td(j["cluster"]),
        html.Td(j.get("slurm_id") or "—"),
        html.Td(j["task_type"]),
        html.Td(badge),
        html.Td(time.strftime("%Y-%m-%d %H:%M",
                              time.localtime(j["created_at"]))),
        html.Td(html.Div(actions, className="d-flex gap-1")),
    ])


def _action_btn(action: str, job_id: int, icon: str, label: str, color: str):
    return dbc.Button(
        [html.I(className=f"bi {icon} me-1"), label],
        id={"type": "job-action", "action": action, "id": str(job_id)},
        size="sm", color=color, outline=True,
    )


# ----- Action implementations -----

def _action_download(cfg: AppConfig, job_id: int, *, partial: bool, clean: bool) -> None:
    job = get_job(job_id)
    if not job:
        return
    cluster = cfg.clusters.get(job["cluster"])
    if cluster is None:
        update_job(job_id, extra={**job["extra"],
                                  "error": f"Cluster {job['cluster']} not configured"})
        return
    dest = cfg.download_dir / f"job_{job_id}_{job['name']}"
    if partial:
        dest = dest.with_name(dest.name + "_partial_" + time.strftime("%H%M%S"))
    try:
        ssh_client.download_dir(cluster, job["remote_dir"], dest, partial=partial)
        log.info("Downloaded job %s → %s", job_id, dest)
        if not partial:
            update_job(job_id, state="DOWNLOADED",
                       extra={**job["extra"], "downloaded_to": str(dest)})
        if clean:
            ssh_client.remove_remote_dir(cluster, job["remote_dir"])
            update_job(job_id, state="CLEANED")
    except Exception as exc:  # noqa: BLE001
        log.exception("Download failed for job %s", job_id)
        update_job(job_id, extra={**job["extra"],
                                  "error": f"download failed: {exc}"})


def _action_cancel(cfg: AppConfig, job_id: int) -> None:
    job = get_job(job_id)
    if not job or not job.get("slurm_id"):
        return
    cluster = cfg.clusters.get(job["cluster"])
    if cluster is None:
        return
    slurm_remote.cancel(cluster, job["slurm_id"])
    update_job(job_id, state="FAILED",
               extra={**job["extra"], "cancelled_by_user": True})


# ===========================================================================
# Tab 3 — Clusters
# ===========================================================================

def _register_cluster_test_callback(app: dash.Dash, cfg: AppConfig) -> None:

    @app.callback(
        Output({"type": "test-cluster-out", "name": dash.MATCH}, "children"),
        Input({"type": "btn-test-cluster", "name": dash.MATCH}, "n_clicks"),
        State({"type": "btn-test-cluster", "name": dash.MATCH}, "id"),
        prevent_initial_call=True,
    )
    def _test(n, btn_id):
        if not n:
            return no_update
        name = btn_id["name"]
        cluster = cfg.clusters.get(name)
        if cluster is None:
            return html.Span("not configured", className="text-danger")
        try:
            rc, out, _ = ssh_client.run(cluster, "hostname && squeue --version", timeout=15)
            if rc == 0:
                return html.Span(f"✓ {out.strip().splitlines()[0]}", className="text-success")
            return html.Span("connected but squeue failed", className="text-warning")
        except Exception as exc:  # noqa: BLE001
            return html.Span(f"✗ {exc}", className="text-danger")
